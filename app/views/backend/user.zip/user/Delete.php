
             <div class="alert alert-danger alert-dismissible">
                <h4><i class="icon fa fa-ban"></i> Atenci&oacute;n!</h4>
                <p><h4 class="text-center">Esta a punto de eliminar al usuario  <?php  echo ucwords( $usuario->nombre ) ?></h4></p>
                <p > <h3 class="text-center"> &iquest:  Desea Continuar ?</h3></p>
              </div>



   


